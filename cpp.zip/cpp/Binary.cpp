#include <iostream>
using namespace std;

class Binary
{
private:
    int size;
    int *arr;

public:
    void getData()
    {
        cout << "Enter the size of array ";
        cin >> size;
        arr = new int[size];
        cout << "Enter array elements : ";
        for (int i = 0; i < size; i++)
        {
            cin >> arr[i];
        }
    }
    void putData()
    {
        cout<<"\n";
        for (int i = 0; i < size; i++)
        {
            cout << arr[i] << "\t";
        }
    }

    int Search()
    {
        int target , index = -1;
        cout << "\nEnter the target : ";
        cin >> target;
        
        int s = 0, e = size-1;
        while (s<=e)
        {
            int mid = (s+e)/2;
            if(arr[mid] == target){
                return mid;
            }else if (arr[mid]>target)
            {
                e =mid-1;
            }else
                s=mid+1;
        }return -1;
        

        
    }
};

int main()
{
    Binary obj;
    obj.getData();
    obj.putData();
    int result = obj.Search();
    if (result == -1)
        {
            cout << "Element not found";
        }
        else
        {
            cout << "Element found at index :"<<result;
        }
    
    obj.putData();
}