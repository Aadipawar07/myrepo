#include <iostream>
using namespace std;

class Linear
{
private:
    int size;
    int *arr;

public:
    void getData()
    {
        cout << "Enter the size of array ";
        cin >> size;
        arr = new int[size];
        cout << "Enter array elements : ";
        for (int i = 0; i < size; i++)
        {
            cin >> arr[i];
        }
    }
    void putData()
    {
        for (int i = 0; i < size; i++)
        {
            cout << arr[i] << "\t";
        }
    }

    int Search()
    {
        int target , index = -1;
        cout << "\nEnter the target : ";
        cin >> target;
        

        for (int i = 0; i < sizeof(arr); i++)
        {
            if (arr[i] == target)
            {
                index = i;
                break;
            }
        }

        if (index == -1)
        {
            cout << "Element not found";
        }
        else
        {
            cout << "Element found at index: " << index;
        }
    }
};

int main()
{
    Linear obj;
    obj.getData();
    obj.putData();
    obj.Search();
    obj.putData();
}