#include <iostream>
using namespace std;

class UnsortedBinary
{
private:
    int size;
    int *arr;

    void sortArray()
    {
        for (int i = 0; i < size - 1; i++)
        {
            for (int j = 0; j < size - i - 1; j++)
            {
                if (arr[j] > arr[j + 1])
                {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

public:
    void getData()
    {
        cout << "Enter the size of array ";
        cin >> size;
        arr = new int[size];
        cout << "Enter array elements : ";
        for (int i = 0; i < size; i++)
        {
            cin >> arr[i];
        }
        sortArray();
        cout << "Array sorted for binary search.\n";
    }
    void putData()
    {
        cout << "\n";
        for (int i = 0; i < size; i++)
        {
            cout << arr[i] << "\t";
        }
    }

    int Search()
    {
        int target;
        cout << "\nEnter the target : ";
        cin >> target;
        int s = 0, e = size - 1;
        while (s <= e)
        {
            int mid = s + (e - s) / 2;
            if (arr[mid] == target)
                return mid;
            else if (arr[mid] > target)
                e = mid - 1;
            else
                s = mid + 1;
        }
        return -1;
    }
};

int main()
{
    UnsortedBinary obj;
    obj.getData();
    obj.putData();
    int result = obj.Search();
    if (result == -1)
    {
        cout << "Element not found";
    }
    else
    {
        cout << "Element found at index :" << result;
    }
    obj.putData();
    return 0;
}
