#include <iostream>
using namespace std;

class Bubble
{
private:
    int size;
    int *arr;

public:
    void sortArray()
    {
        for (int i = 0; i < size - 1; i++)
        {
            for (int j = 0; j < size - i - 1; j++)
            {
                if (arr[j] > arr[j + 1])
                {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    void getData()
    {
        cout << "Enter the size of array ";
        cin >> size;
        arr = new int[size];
        cout << "Enter array elements : ";
        for (int i = 0; i < size; i++)
        {
            cin >> arr[i];
        }
    }
    void putData()
    {
        cout << "\n";
        for (int i = 0; i < size; i++)
        {
            cout << arr[i] << "\t";
        }
    }
};

int main()
{
    Bubble obj;
    obj.getData();
    cout << "Before Sort : ";
    obj.putData();
    obj.sortArray();
    cout << "\nAfter Sort : ";
    obj.putData();
    return 0;
}
